function runSheetsCheck() {
  return checkSheets();
}
