function runTestsCheck() {
  return testFunctions();
}
