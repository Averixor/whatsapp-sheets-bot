function runFilesCheck() {
  return checkFiles();
}
