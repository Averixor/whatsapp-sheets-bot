function runDuplicatesCheck() {
  return checkDuplicates();
}
