function runAllDiagnostics() {
  return runDiagnostics();
}
